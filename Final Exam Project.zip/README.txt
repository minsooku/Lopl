Team Members:
Jiheon Kim (jkim0728) - 117663853
Joonhyung Park (jpark142) - 11937839
Minsoo Ku (mku1) - 118994239

Lopl (Local Places):
Lopl is a web app that can allow users to save their favorite/interesting places
by creating a post with some pieces of information about the place. Once a user
saves their favorite place, they will be able to revisit what they have written
in their posts.

Procedure to run the program locally:
npm init
npm install
node lopl.js <PORT NUMBER>

Google Maps Geocoding API:
https://developers.google.com/maps/documentation/geocoding/overview

Google Maps Places API:
https://developers.google.com/maps/documentation/places/web-service/overview

Video Link:
https://youtu.be/-l_kCYwXFe4

Website Link:
https://lopl-q28y.onrender.com